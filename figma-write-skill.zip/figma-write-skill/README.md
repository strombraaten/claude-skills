# Figma Write Skill for Claude Code

A Claude Code skill that teaches Claude how to **write designs into Figma files** using the official Figma MCP server.

## The Problem

Claude Code users often find that Claude thinks the Figma MCP is read-only. **It's not.** The official Figma MCP server at `https://mcp.figma.com/mcp` includes the `generate_figma_design` tool which writes editable design layers into Figma files.

## What This Skill Does

This skill teaches Claude the correct workflow for creating designs in Figma:

1. **Build UI as HTML/CSS** — Create the design as local web pages
2. **Serve locally** — Run a dev server (Python, npx serve, Vite, etc.)
3. **Use `generate_figma_design`** — Capture the live UI into Figma as editable layers
4. **Verify** — Use read tools to confirm the design was created correctly

## Prerequisites

- **Figma MCP plugin**: `claude plugin install figma@claude-plugins-official`
- **Figma authentication**: OAuth via `/mcp` → select `figma` → Authenticate
- **Figma seat**: Full or Dev seat on Professional, Organization, or Enterprise plan

## Installation

Copy the `skills/figma-write-to-figma/` directory into your Claude Code plugins or project skills directory.

Or share this repo with anyone who needs it — the SKILL.md file contains all the instructions Claude needs.

## Usage

Once installed, Claude will automatically use this skill when you say things like:

- "Create a design in Figma"
- "Write this UI to my Figma file"
- "Push these designs to Figma"
- "Design a dashboard and put it in Figma at [URL]"

## Troubleshooting

**`generate_figma_design` not showing up?**
→ Authenticate via `/mcp` and restart the Claude Code session

**"User does not have permission"?**
→ You need a Full or Dev seat on a paid Figma plan

## Credits

Created by Smpl Co / Melvær & Co. Built with Claude Code.
